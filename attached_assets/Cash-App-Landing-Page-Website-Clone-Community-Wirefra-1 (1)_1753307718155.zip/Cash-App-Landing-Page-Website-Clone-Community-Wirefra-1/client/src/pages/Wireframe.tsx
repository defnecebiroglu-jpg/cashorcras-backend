import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export const Wireframe = (): JSX.Element => {
  const [accessCode, setAccessCode] = useState("");
  // Vector images data
  const vectors = [
    {
      className: "top-[423px] left-0 absolute w-[265px] h-[229px]",
      alt: "Vector",
      src: "/figmaAssets/vector-2.svg",
    },
    {
      className: "top-0 left-[921px] absolute w-[265px] h-[229px]",
      alt: "Vector",
      src: "/figmaAssets/vector-3.svg",
    },
  ];

  return (
    <div className="bg-[#1b1b1b] flex flex-row justify-center w-full">
      <div className="bg-[#1b1b1b] overflow-hidden w-[1440px] h-[1165px] relative">
        {/* Header text */}
        <div className="absolute w-[3432px] top-[154px] left-[-996px] [font-family:'Bowlby_One',Helvetica] font-normal text-[#cbed46] text-8xl text-center tracking-[0] leading-[80px] whitespace-nowrap">
          RASH OR CASH OR CRASH OR CAS
        </div>

        <div className="absolute w-[1186px] h-[652px] top-[347px] left-[127px]">
          {/* Vector images */}
          {vectors.map((vector, index) => (
            <img
              key={`vector-${index}`}
              className={vector.className}
              alt={vector.alt}
              src={vector.src}
            />
          ))}

          {/* Login Card */}
          <Card className="flex flex-col w-[700px] items-start gap-[42px] p-10 absolute top-[65px] left-[243px] bg-[#1b1b1b] rounded-[25px] border-4 border-solid border-[#aa95c7]">
            <CardContent className="p-0 w-full">
              <div className="relative self-stretch h-[74px] mt-[-4.00px] [font-family:'Bowlby_One',Helvetica] font-normal text-[#e3dfd6] text-5xl text-center tracking-[0] leading-[80px] whitespace-nowrap">
                TAKIM GIRISI
              </div>

              <div className="relative self-stretch h-10 mt-[42px] [font-family:'Inter',Helvetica] font-extrabold text-[#e3dfd6] text-[32px] tracking-[0] leading-[60px] whitespace-nowrap">
                Erişim Kodu
              </div>

              <div className="relative self-stretch w-full h-[60px] mt-[42px]">
                <Input
                  className="h-[60px] bg-[#aa95c766] rounded-lg border-2 border-solid border-[#aa95c7] [font-family:'Inter',Helvetica] font-normal text-[#e3dfd6] text-3xl"
                  placeholder="Takım erişim kodunu giriniz"
                  value={accessCode}
                  onChange={(e) => setAccessCode(e.target.value)}
                />
              </div>

              <Button 
                className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 text-primary-foreground shadow px-4 py-2 h-[60px] mt-[42px] w-full rounded-lg transition-colors hover:bg-[#d3cfc6] bg-[#aa95c7]"
                disabled={accessCode.trim().length === 0}
              >
                <span className="[font-family:'Bowlby_One',Helvetica] font-normal text-[32px] text-center tracking-[0] text-[#1b1b1b]">
                  GIRIS YAP
                </span>
              </Button>

              <div className="relative self-stretch w-full h-10 mt-[42px] text-center">
                <span className="[font-family:'Inter',Helvetica] font-normal text-[#e3dfd6] text-3xl tracking-[0] leading-10">
                  Admin girişi için{" "}
                </span>
                <span className="[font-family:'Inter',Helvetica] font-medium text-[#cbed46] text-3xl tracking-[0] leading-10 cursor-pointer">
                  buraya tıklayınız
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Navigation Bar */}
        <div className="flex w-[1440px] items-end justify-between p-8 absolute top-0 left-px">
          <div className="relative w-[348px] h-[47px] [font-family:'Bowlby_One',Helvetica] font-normal text-[#e3dfd6] text-2xl tracking-[0] leading-[normal]">
            KALGIRISIMCILIK
          </div>

          <div className="flex w-[397px] items-end gap-10 relative">
            <div className="relative w-[148px] h-[47px] [font-family:'Bowlby_One',Helvetica] font-normal text-[#1b1b1b] text-2xl tracking-[0] leading-[normal]">
              HAKKINDA
            </div>

            <Button className="h-[50px] px-6 bg-[#aa95c7] rounded-lg hover:bg-[#9a85b7]">
              <span className="[font-family:'Bowlby_One',Helvetica] font-normal text-[#1b1b1b] text-2xl text-center tracking-[0] leading-[normal]">
                GIRIS YAP
              </span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
